# Online Exam System — Deployable MVP

A small full-stack MCQ exam platform for a teacher and multiple students.

## Features
- Teacher password login
- Create tests with multiple-choice questions
- Timer with automatic submission
- Positive marks + negative marking
- Publish/unpublish tests
- Unique test code and shareable student URL
- Student name + roll number
- Server-side scoring
- Prevents a second attempt for the same name + roll number on the same test
- Teacher results table with rank, score, percentage, correct/wrong/unattempted
- CSV export
- JSON file persistence (`data/db.json`)

## Run on a computer
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Set a strong teacher password:
   - Windows PowerShell: `$env:TEACHER_PASSWORD="your-strong-password"`
   - macOS/Linux: `export TEACHER_PASSWORD="your-strong-password"`
5. Run `npm start`.
6. Open `http://localhost:3000`.

If you do not set `TEACHER_PASSWORD`, the local default is `change-me-123`. Change it before any real use.

## How students get the exam
Teacher logs in → creates a test → publishes it → clicks **Copy Link** → sends that URL to students on WhatsApp/Telegram/Google Classroom.

## Deployment
This app needs a Node.js host with writable persistent storage because results are stored in `data/db.json`. For real use, use HTTPS and a strong password. For larger classes or high-stakes exams, replace the JSON store with a managed database and add proper teacher authentication.

## Important MVP limitations
- JSON file storage is intended for small-scale use, not high concurrency.
- Teacher authentication is a single shared password.
- The browser timer is backed by a server-side expiry check, but this is not a hardened proctoring system.
- No webcam/proctoring, question randomization, email/SMS, or payment features.
