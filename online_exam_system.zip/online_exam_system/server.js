const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const TEACHER_PASSWORD = process.env.TEACHER_PASSWORD || 'change-me-123';
const DB_FILE = path.join(__dirname, 'data', 'db.json');

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function loadDb() {
  if (!fs.existsSync(DB_FILE)) {
    const initial = { tests: [], attempts: [], results: [] };
    fs.writeFileSync(DB_FILE, JSON.stringify(initial, null, 2));
    return initial;
  }
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return { tests: [], attempts: [], results: [] }; }
}
function saveDb(db) {
  fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function id() { return crypto.randomUUID(); }
function code() { return crypto.randomBytes(4).toString('hex').toUpperCase(); }
function teacher(req, res, next) {
  if (req.header('x-teacher-password') !== TEACHER_PASSWORD) return res.status(401).json({error:'Teacher authentication required.'});
  next();
}
function publicTest(t) {
  return {
    id:t.id, code:t.code, title:t.title, className:t.className,
    durationMinutes:t.durationMinutes, marksPerQuestion:t.marksPerQuestion,
    negativeMarking:t.negativeMarking, published:t.published,
    questionCount:t.questions.length,
    questions:t.questions.map(q => ({ id:q.id, text:q.text, options:q.options }))
  };
}
function validateTest(body) {
  if (!body.title || !body.className) return 'Test title and class are required.';
  const duration = Number(body.durationMinutes);
  const marks = Number(body.marksPerQuestion);
  if (!Number.isFinite(duration) || duration < 1 || duration > 600) return 'Duration must be 1–600 minutes.';
  if (!Number.isFinite(marks) || marks <= 0) return 'Marks/question must be positive.';
  if (!Array.isArray(body.questions) || body.questions.length < 1) return 'Add at least one question.';
  for (const q of body.questions) {
    if (!q.text || !Array.isArray(q.options) || q.options.length < 2 || q.options.length > 6) return 'Each question needs 2–6 options.';
    if (!Number.isInteger(q.correctIndex) || q.correctIndex < 0 || q.correctIndex >= q.options.length) return 'Each question needs a valid correct answer.';
    if (q.options.some(o => !String(o).trim())) return 'Options cannot be empty.';
  }
  return null;
}

app.post('/api/teacher/login', (req,res) => {
  if (req.body?.password !== TEACHER_PASSWORD) return res.status(401).json({error:'Incorrect password.'});
  res.json({ok:true});
});

app.get('/api/tests', teacher, (req,res) => {
  const db=loadDb();
  res.json(db.tests.map(t => ({...t, questionCount:t.questions.length})));
});

app.post('/api/tests', teacher, (req,res) => {
  const error=validateTest(req.body || {}); if(error) return res.status(400).json({error});
  const db=loadDb();
  let testCode; do { testCode=code(); } while(db.tests.some(t=>t.code===testCode));
  const test={
    id:id(), code:testCode, title:String(req.body.title).trim(), className:String(req.body.className).trim(),
    durationMinutes:Number(req.body.durationMinutes), marksPerQuestion:Number(req.body.marksPerQuestion),
    negativeMarking:Number(req.body.negativeMarking||0), published:!!req.body.published,
    createdAt:new Date().toISOString(),
    questions:req.body.questions.map(q=>({id:id(), text:String(q.text).trim(), options:q.options.map(String), correctIndex:q.correctIndex}))
  };
  db.tests.push(test); saveDb(db); res.json(test);
});

app.patch('/api/tests/:id', teacher, (req,res) => {
  const db=loadDb(); const t=db.tests.find(x=>x.id===req.params.id); if(!t) return res.status(404).json({error:'Test not found.'});
  if (typeof req.body.published === 'boolean') t.published=req.body.published;
  if (typeof req.body.title === 'string') t.title=req.body.title.trim();
  saveDb(db); res.json(t);
});

app.delete('/api/tests/:id', teacher, (req,res) => {
  const db=loadDb(); db.tests=db.tests.filter(t=>t.id!==req.params.id); db.attempts=db.attempts.filter(a=>a.testId!==req.params.id); db.results=db.results.filter(r=>r.testId!==req.params.id); saveDb(db); res.json({ok:true});
});

app.get('/api/public-tests', (req,res) => {
  const db=loadDb(); res.json(db.tests.filter(t=>t.published).map(publicTest));
});

app.get('/api/public-tests/:code', (req,res) => {
  const db=loadDb(); const t=db.tests.find(x=>x.code===req.params.code.toUpperCase() && x.published); if(!t) return res.status(404).json({error:'Published test not found.'}); res.json(publicTest(t));
});

app.post('/api/public-tests/:code/start', (req,res) => {
  const db=loadDb(); const t=db.tests.find(x=>x.code===req.params.code.toUpperCase() && x.published); if(!t) return res.status(404).json({error:'Published test not found.'});
  const studentName=String(req.body?.studentName||'').trim(); const rollNo=String(req.body?.rollNo||'').trim();
  if(!studentName || !rollNo) return res.status(400).json({error:'Student name and roll number are required.'});
  const key=(studentName+'|'+rollNo).toLowerCase();
  const existing=db.results.find(r=>r.testId===t.id && r.attemptKey===key);
  if(existing) return res.status(409).json({error:'An attempt already exists for this student/roll number.', resultId:existing.id});
  const attemptId=id(); const startedAt=Date.now();
  db.attempts.push({id:attemptId,testId:t.id,studentName,rollNo,startedAt,expiresAt:startedAt+t.durationMinutes*60000,submitted:false});
  saveDb(db); res.json({attemptId, startedAt, expiresAt:startedAt+t.durationMinutes*60000, test:publicTest(t)});
});

app.post('/api/public-tests/:code/submit', (req,res) => {
  const db=loadDb(); const t=db.tests.find(x=>x.code===req.params.code.toUpperCase() && x.published); if(!t) return res.status(404).json({error:'Test not found.'});
  const a=db.attempts.find(x=>x.id===req.body?.attemptId && x.testId===t.id); if(!a) return res.status(400).json({error:'Invalid attempt.'});
  if(a.submitted) return res.status(409).json({error:'This attempt has already been submitted.'});
  const answers=Array.isArray(req.body.answers)?req.body.answers:[];
  let correct=0, wrong=0, unattempted=0;
  const answerMap=new Map(answers.map(x=>[x.questionId, Number(x.answerIndex)]));
  for(const q of t.questions){
    const ans=answerMap.get(q.id);
    if(!Number.isInteger(ans) || ans<0){unattempted++;}
    else if(ans===q.correctIndex){correct++;}
    else {wrong++;}
  }
  const score=correct*t.marksPerQuestion - wrong*t.negativeMarking;
  const maxScore=t.questions.length*t.marksPerQuestion;
  const result={id:id(),testId:t.id,testTitle:t.title,attemptKey:(a.studentName+'|'+a.rollNo).toLowerCase(),studentName:a.studentName,rollNo:a.rollNo,correct,wrong,unattempted,score,maxScore,percentage:maxScore?Math.max(0,score/maxScore*100):0,submittedAt:new Date().toISOString()};
  a.submitted=true; a.submittedAt=result.submittedAt; db.results.push(result); saveDb(db); res.json(result);
});

app.get('/api/results', teacher, (req,res) => {
  const db=loadDb(); let rows=db.results;
  if(req.query.testId) rows=rows.filter(r=>r.testId===req.query.testId);
  rows=rows.map(r=>({...r,rank:1}));
  const sorted=[...rows].sort((a,b)=>b.score-a.score || new Date(a.submittedAt)-new Date(b.submittedAt));
  let lastScore=null, rank=0; sorted.forEach((r,i)=>{ if(r.score!==lastScore) rank=i+1; r.rank=rank; lastScore=r.score; });
  const ranks=new Map(sorted.map(r=>[r.id,r.rank])); rows.forEach(r=>r.rank=ranks.get(r.id)||1);
  res.json(rows.sort((a,b)=>new Date(b.submittedAt)-new Date(a.submittedAt)));
});

app.get('/api/results.csv', teacher, (req,res) => {
  const db=loadDb(); let rows=db.results; if(req.query.testId) rows=rows.filter(r=>r.testId===req.query.testId);
  const head=['Student Name','Roll No.','Test','Correct','Wrong','Unattempted','Score','Max Score','Percentage','Submitted At'];
  const esc=v=>'"'+String(v??'').replaceAll('"','""')+'"';
  const csv=[head,...rows.map(r=>[r.studentName,r.rollNo,r.testTitle,r.correct,r.wrong,r.unattempted,r.score,r.maxScore,r.percentage.toFixed(2),r.submittedAt].map(esc))].map(x=>x.join(',')).join('\n');
  res.setHeader('Content-Type','text/csv'); res.setHeader('Content-Disposition','attachment; filename="exam-results.csv"'); res.send(csv);
});

app.get('*', (req,res) => res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`Online Exam System running on http://localhost:${PORT}`));
